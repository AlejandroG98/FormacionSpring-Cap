package com.example.domains.entities.dtos;

public interface LanguageShort {

	int getLanguageId();
	String getName();
}
