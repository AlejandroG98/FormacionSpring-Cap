# Curso 
Esto es una prueba del curso <br/>
demo: Todo lo hecho en clase <br/>
Catalogo: Prueba con las entidades Film, Language y Category
